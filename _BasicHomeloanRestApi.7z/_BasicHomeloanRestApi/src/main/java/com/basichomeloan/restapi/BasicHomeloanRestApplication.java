package com.basichomeloan.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@SpringBootApplication
@EnableOpenApi
@EnableWebMvc
public class BasicHomeloanRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicHomeloanRestApplication.class, args);
	}

    @Bean
    public Docket api()
    {
        return new Docket(DocumentationType.OAS_30)
                .select()
                .paths(PathSelectors.ant("/basichomeloan/**"))
                .apis(RequestHandlerSelectors.any())
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo()
    {
        return new ApiInfoBuilder()
                .title("BasicHomeloan REST API")
                .description("BasicHomeloan REST APIs are used to interact with the Server Application")
                .version("1.0.0")
                .license("BasicHomeloan License Version 2.0")
                .licenseUrl("https://www.BasicHomeloan.com/licenses/LICENSE-2.0")
                .contact(new Contact("support", "www.BasicHomeloan.com", "support@BasicHomeloan.com"))
                .build();
    }
}
